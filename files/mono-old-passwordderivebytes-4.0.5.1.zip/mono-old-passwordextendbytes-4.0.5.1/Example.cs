using System;
using MonoOld.System.Security.Cryptography;

namespace MonoOldExample {
	class Program {
		static void Main (string [] args)
		{
			// Password and random salt
			PasswordDeriveBytes pdb =
				new PasswordDeriveBytes(
					"The world wonders",
					new byte[] {0xb5, 0x10, 0x4, 0x16, 0x51, 0x65,
						0x3e, 0xa0, 0xe7, 0xec, 0xfa, 0x13, 0xc1});

			byte[] bytes1 = pdb.GetBytes(32);
			byte[] bytes2 = pdb.GetBytes(16);

			string string1 = BitConverter.ToString(bytes1);
			string string2 = BitConverter.ToString(bytes2);

			string expected2 = "9E-2D-EB-4C-DD-B4-CE-54-DE-7C-F7-C9-57-22-CB-FD";

			Console.WriteLine("Results:");
			Console.WriteLine(string1);
			Console.WriteLine(string2);
			Console.WriteLine(string2 == expected2 ? "Success" : "Failure");
		}
	}
}