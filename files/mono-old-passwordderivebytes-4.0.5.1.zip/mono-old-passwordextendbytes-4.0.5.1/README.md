This is a standalone package of the `PasswordDeriveBytes` class and supporting classes from Mono corlib 4.0.5.1. It can be used if you need 4.0-compatible behavior for this class in Mono 4.2 or later. For more details, please see the [Mono 4.2.1 release notes](http://www.mono-project.com/docs/about-mono/releases/4.2.1/).

# Usage

Include the contents of the MonoOld.System.Security.Cryptography directory into your project.

An example is included. To run it, try:

    mcs Example.cs MonoOld.System.Security.Cryptography/*
    mono Example.exe

# Extending

The included code works only with the default hash of SHA1. If you need to support other hash types, you will need to check out Mono 4.0.5.1, copy the appropriate classes in from `System.Security.Cryptography`, and then add them to the `Create` function in `MonoOld.System.Security.Cryptography`.
